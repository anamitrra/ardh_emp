<link rel="stylesheet" href="css/nav.css">

<nav>
        <h2>AARADHAYA HEALTH CARE </h2>
        <div class="links">
            <a href="registration.php">Registration</a>
            <a href="view-customers.php">View</a>
            <a href="logout.php">Logout</a>
        </div>
    </nav>