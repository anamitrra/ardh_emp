<?php

$con=mysqli_connect("localhost","root1","pass","ardhemp")or die("can't connect...");
?>